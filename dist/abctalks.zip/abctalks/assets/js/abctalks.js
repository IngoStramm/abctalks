document.addEventListener('DOMContentLoaded', function () {
    // code
});