<?php

/**
 * abctalks_main_playlist_shortcode
 *
 * Retorna os útlimos 4 quatro vídeos da playlist principal
 * 
 * @param  array $atts
 * @return string
 */
function abctalks_main_playlist_shortcode($atts)
{
    $playlist_id = abctalks_get_option('main_playlist_id');
    $atts = shortcode_atts(array(
        'playlist_id' => $playlist_id ? $playlist_id : '',
        'max_results' => 4,
        'layout'        => 'two-columns'
    ), $atts);

    return abctalks_playlist_output($atts);
}

/**
 * abctalks_cuts_playlist_shortcode
 *
 * Retorna os útlimos 4 quatro vídeos da playlist de cortes
 * 
 * @param  array $atts
 * @return string
 */
function abctalks_cuts_playlist_shortcode($atts)
{
    $playlist_id = abctalks_get_option('cuts_playlist_id');
    $atts = shortcode_atts(array(
        'playlist_id' => $playlist_id ? $playlist_id : '',
        'max_results' => 3,
        'layout'        => 'three-columns'
    ), $atts);

    return abctalks_playlist_output($atts);
}

/**
 * abctalks_last_video_main_playlist_shortcode
 *
 * Retorna o vídeo mais recente da playlist principal
 * 
 * @param  array $atts
 * @return string
 */
function abctalks_last_video_main_playlist_shortcode($atts)
{
    $playlist_id = abctalks_get_option('main_playlist_id');
    $atts = shortcode_atts(array(
        'playlist_id' => $playlist_id ? $playlist_id : '',
        'max_results' => 1
    ), $atts);

    return abctalks_playlist_output($atts);
}

/**
 * abctalks_get_youtube_playlist_description
 *
 * Retorna a descrição do vídeo mais recente da playlist principal
 * 
 * @return string
 */
function abctalks_get_youtube_playlist_description_shortcode()
{
    $main_playlist_videos = get_transient('main_playlist_videos');
    return $main_playlist_videos[0]['video_description'];
}

add_shortcode('abctalks_last_video_main_playlist', 'abctalks_last_video_main_playlist_shortcode');
add_shortcode('abctalks_playlist_description', 'abctalks_get_youtube_playlist_description_shortcode');
add_shortcode('abctalks_main_playlist', 'abctalks_main_playlist_shortcode');
add_shortcode('abctalks_cuts_playlist', 'abctalks_cuts_playlist_shortcode');
